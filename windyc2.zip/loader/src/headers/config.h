#pragma once

#define HTTP_SERVER "161.97.180.220"
#define HTTP_PORT 80

#define TFTP_SERVER "161.97.180.220"
